document.addEventListener("DOMContentLoaded", fetchStudents);

const form = document.querySelector("#student-form");
form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const firstName = document.querySelector("#firstName").value.trim();
    const lastName = document.querySelector("#lastName").value.trim();
    const rollNo = document.querySelector("#rollNo").value.trim();

    if (!firstName || !lastName || !rollNo) {
        alert("Please fill in all fields");
        return;
    }

    try {
        await fetch("http://localhost:5432/students", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ firstName, lastName, rollNo }),
        });
        fetchStudents();
        form.reset();
    } catch (err) {
        console.error("Error adding student:", err);
    }
});

async function fetchStudents() {
    try {
        const response = await fetch("http://localhost:5432/students");
        const students = await response.json();

        const studentList = document.querySelector("#student-list");
        studentList.innerHTML = ""; // Clear table

        students.forEach((student) => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${student.first_name}</td>
                <td>${student.last_name}</td>
                <td>${student.roll_no}</td>
                <td>
                    <button class="btn btn-danger btn-sm" onclick="deleteStudent(${student.id})">Delete</button>
                </td>
            `;
            studentList.appendChild(row);
        });
    } catch (err) {
        console.error("Error fetching students:", err);
    }
}

async function deleteStudent(id) {
    try {
        await fetch(`http://localhost:5000/students/${id}`, {
            method: "DELETE",
        });
        fetchStudents();
    } catch (err) {
        console.error("Error deleting student:", err);
    }
}
