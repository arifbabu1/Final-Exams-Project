const express = require("express");
const bodyParser = require("body-parser");
const { Pool } = require("pg");
const cors = require("cors");

const app = express();
const port = 5432;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// PostgreSQL Connection
const pool = new Pool({
    user: "your_username",
    host: "localhost",
    database: "studentdb",
    password: "your_password",
    port: 5432,
});

// Add Student
app.post("/students", async (req, res) => {
    const { firstName, lastName, rollNo } = req.body;
    try {
        const result = await pool.query(
            "INSERT INTO students (first_name, last_name, roll_no) VALUES ($1, $2, $3) RETURNING *",
            [firstName, lastName, rollNo]
        );
        res.status(201).json(result.rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).send("Server error");
    }
});

// Get All Students
app.get("/students", async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM students");
        res.status(200).json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).send("Server error");
    }
});

// Delete Student
app.delete("/students/:id", async (req, res) => {
    const { id } = req.params;
    try {
        await pool.query("DELETE FROM students WHERE id = $1", [id]);
        res.status(200).send("Student deleted");
    } catch (err) {
        console.error(err);
        res.status(500).send("Server error");
    }
});

// Start Server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
